import streamlit as st
from io import BytesIO

from document_reader import (
    validate_pdf,
    extract_text_from_pdf,
    get_document_info,
    validate_combined_length,
)

from comparison import compare_documents, ComparisonResult

from docx import Document


# =========================================================
# PAGE CONFIGURATION
# =========================================================

st.set_page_config(
    page_title="AI Document Comparison Assistant",
    page_icon="📄",
    layout="wide",
)


# =========================================================
# TITLE AND DESCRIPTION
# =========================================================

st.title("📄 AI Document Comparison Assistant")

st.write(
    "Upload two PDF documents to compare summaries, similarities, "
    "differences, dates, amounts, requirements, and other key details."
)

st.caption(
    "Supports text-based PDFs. Scanned PDFs require OCR, "
    "which is not included in this version."
)


# =========================================================
# SESSION STATE
# =========================================================

if "comparison_result" not in st.session_state:
    st.session_state.comparison_result = None

if "doc_a_name" not in st.session_state:
    st.session_state.doc_a_name = ""

if "doc_b_name" not in st.session_state:
    st.session_state.doc_b_name = ""


# =========================================================
# RESET
# =========================================================

if st.button("🔄 Reset / Start New Comparison"):
    st.session_state.comparison_result = None
    st.session_state.doc_a_name = ""
    st.session_state.doc_b_name = ""
    st.rerun()


# =========================================================
# PDF UPLOAD
# =========================================================

col1, col2 = st.columns(2)

with col1:
    st.subheader("📄 Document A")
    file_a = st.file_uploader(
        "Upload the first PDF",
        type=["pdf"],
        key="document_a",
    )

with col2:
    st.subheader("📄 Document B")
    file_b = st.file_uploader(
        "Upload the second PDF",
        type=["pdf"],
        key="document_b",
    )


# =========================================================
# DOCUMENT PREVIEW
# =========================================================

def preview_pdf(uploaded_file, label):
    if uploaded_file is None:
        return

    st.success(f"{label} selected: {uploaded_file.name}")

    try:
        valid, message = validate_pdf(uploaded_file)

        if not valid:
            st.error(f"{label}: {message}")
            return

        text, page_count = extract_text_from_pdf(uploaded_file)

        if not text.strip():
            st.error(
                f"{label}: No readable text was found. "
                "The PDF may be empty or scanned."
            )
            return

        info = get_document_info(text, page_count)

        with st.expander(f"{label} - Extraction Information"):
            st.write(f"**Pages:** {info['pages']}")
            st.write(
                f"**Characters extracted:** "
                f"{info['characters']:,}"
            )
            st.text_area(
                "Text preview",
                info["preview"],
                height=180,
                key=f"preview_{label}",
            )

    except Exception as exc:
        st.error(f"Could not read {label}: {exc}")


preview_pdf(file_a, "Document A")
preview_pdf(file_b, "Document B")


# =========================================================
# COMPARE DOCUMENTS
# =========================================================

st.divider()

if st.button(
    "🔍 Compare Documents",
    type="primary",
    use_container_width=True,
):

    if file_a is None or file_b is None:
        st.error("Please upload both PDF documents.")

    else:
        try:
            with st.spinner("Validating and reading PDFs..."):

                valid_a, message_a = validate_pdf(file_a)
                valid_b, message_b = validate_pdf(file_b)

                if not valid_a:
                    st.error(f"Document A: {message_a}")
                    st.stop()

                if not valid_b:
                    st.error(f"Document B: {message_b}")
                    st.stop()

                text_a, pages_a = extract_text_from_pdf(file_a)
                text_b, pages_b = extract_text_from_pdf(file_b)

                if not text_a.strip():
                    st.error(
                        "Document A contains no readable text."
                    )
                    st.stop()

                if not text_b.strip():
                    st.error(
                        "Document B contains no readable text."
                    )
                    st.stop()

                length_ok, length_message = validate_combined_length(
                    text_a,
                    text_b,
                )

                if not length_ok:
                    st.error(length_message)
                    st.stop()

            with st.spinner(
                "🤖 Gemini AI is comparing both documents..."
            ):

                # IMPORTANT: pass both extracted documents.
                result = compare_documents(
                    document_a=text_a,
                    document_b=text_b,
                )

                st.session_state.comparison_result = result
                st.session_state.doc_a_name = file_a.name
                st.session_state.doc_b_name = file_b.name

        except Exception as exc:
            st.error(f"Comparison failed: {exc}")


# =========================================================
# DISPLAY RESULTS
# =========================================================

result = st.session_state.comparison_result

if result is not None:

    st.divider()
    st.header("📊 Comparison Results")

    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
        [
            "Summary A",
            "Summary B",
            "Similarities",
            "Differences",
            "Key Details",
            "Conclusion & Limitations",
        ]
    )

    # -----------------------------------------------------
    # SUMMARY A
    # -----------------------------------------------------

    with tab1:
        st.subheader(st.session_state.doc_a_name)
        st.write(result.summary_a)

    # -----------------------------------------------------
    # SUMMARY B
    # -----------------------------------------------------

    with tab2:
        st.subheader(st.session_state.doc_b_name)
        st.write(result.summary_b)

    # -----------------------------------------------------
    # SIMILARITIES
    # -----------------------------------------------------

    with tab3:
        if result.similarities:
            for index, item in enumerate(
                result.similarities,
                start=1,
            ):
                st.markdown(f"**{index}.** {item}")
        else:
            st.info("No similarities were returned by the model.")

    # -----------------------------------------------------
    # DIFFERENCES
    # -----------------------------------------------------

    with tab4:
        if result.differences:
            for index, item in enumerate(
                result.differences,
                start=1,
            ):
                st.markdown(f"### Difference {index}")
                st.write(f"**Topic:** {item.topic}")
                st.write(
                    f"**Document A:** {item.document_a}"
                )
                st.write(
                    f"**Document B:** {item.document_b}"
                )
                st.divider()
        else:
            st.info("No differences were returned by the model.")

    # -----------------------------------------------------
    # KEY DETAILS
    # -----------------------------------------------------

    with tab5:
        if result.key_details:
            for index, item in enumerate(
                result.key_details,
                start=1,
            ):
                st.markdown(f"### {index}. {item.category}")

                left, right = st.columns(2)

                with left:
                    st.write("**Document A**")
                    st.write(item.document_a)

                with right:
                    st.write("**Document B**")
                    st.write(item.document_b)

                st.divider()
        else:
            st.info("No key details were returned by the model.")

    # -----------------------------------------------------
    # CONCLUSION AND LIMITATIONS
    # -----------------------------------------------------

    with tab6:
        st.subheader("Overall Conclusion")
        st.write(result.conclusion)

        st.subheader("Limitations")

        if result.limitations:
            for limitation in result.limitations:
                st.warning(limitation)
        else:
            st.info(
                "No additional limitations were returned by the model."
            )

    # =====================================================
    # DOWNLOAD DOCX REPORT
    # =====================================================

    st.divider()
    st.subheader("📥 Download Comparison Report")

    try:
        report = Document()

        report.add_heading(
            "AI Document Comparison Report",
            level=0,
        )

        report.add_heading("Document A", level=1)
        report.add_paragraph(
            f"File: {st.session_state.doc_a_name}"
        )
        report.add_paragraph(result.summary_a)

        report.add_heading("Document B", level=1)
        report.add_paragraph(
            f"File: {st.session_state.doc_b_name}"
        )
        report.add_paragraph(result.summary_b)

        report.add_heading("Similarities", level=1)

        if result.similarities:
            for item in result.similarities:
                report.add_paragraph(item, style="List Bullet")
        else:
            report.add_paragraph("No similarities returned.")

        report.add_heading("Differences", level=1)

        if result.differences:
            for item in result.differences:
                report.add_heading(item.topic, level=2)
                report.add_paragraph(
                    f"Document A: {item.document_a}"
                )
                report.add_paragraph(
                    f"Document B: {item.document_b}"
                )
        else:
            report.add_paragraph("No differences returned.")

        report.add_heading("Key Details Comparison", level=1)

        if result.key_details:
            for item in result.key_details:
                report.add_heading(item.category, level=2)
                report.add_paragraph(
                    f"Document A: {item.document_a}"
                )
                report.add_paragraph(
                    f"Document B: {item.document_b}"
                )
        else:
            report.add_paragraph("No key details returned.")

        report.add_heading("Overall Conclusion", level=1)
        report.add_paragraph(result.conclusion)

        report.add_heading("Limitations", level=1)

        if result.limitations:
            for item in result.limitations:
                report.add_paragraph(item, style="List Bullet")
        else:
            report.add_paragraph(
                "No additional limitations returned."
            )

        report.add_paragraph(
            "This tool provides informational comparisons only. "
            "It does not provide legal advice or determine legal compliance."
        )

        output = BytesIO()
        report.save(output)
        output.seek(0)

        st.download_button(
            label="📥 Download Comparison Report (.docx)",
            data=output.getvalue(),
            file_name="document_comparison_report.docx",
            mime=(
                "application/vnd.openxmlformats-officedocument."
                "wordprocessingml.document"
            ),
            use_container_width=True,
        )

    except Exception as exc:
        st.error(f"Could not generate report: {exc}")


# =========================================================
# FOOTER
# =========================================================

st.divider()

st.caption(
    "AI Document Comparison Assistant | "
    "Informational comparison only. "
    "Always verify important findings against the original documents."
)