import json
import re
from pathlib import Path
from typing import List

from pydantic import BaseModel, Field
from google import genai


# ============================================================
# SETTINGS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
ENV_FILE = BASE_DIR / ".env"

DEFAULT_MODEL = "gemini-2.5-flash"
MAX_TOTAL_CHARS = 120000


# ============================================================
# READ .ENV MANUALLY
# This avoids dotenv/path problems.
# ============================================================

def get_env_value(name: str):
    """
    Read a value directly from the .env file.
    """

    if not ENV_FILE.exists():
        raise RuntimeError(
            f".env file not found.\nExpected location:\n{ENV_FILE}"
        )

    try:
        content = ENV_FILE.read_text(
            encoding="utf-8-sig"
        )
    except Exception as e:
        raise RuntimeError(
            f"Could not read .env file:\n{e}"
        )

    for raw_line in content.splitlines():

        line = raw_line.strip()

        # Ignore blank lines
        if not line:
            continue

        # Ignore comments
        if line.startswith("#"):
            continue

        if line.startswith(name + "="):

            value = line.split("=", 1)[1].strip()

            # Remove optional quotes
            if (
                len(value) >= 2
                and value[0] == '"'
                and value[-1] == '"'
            ):
                value = value[1:-1]

            if (
                len(value) >= 2
                and value[0] == "'"
                and value[-1] == "'"
            ):
                value = value[1:-1]

            value = value.strip()

            if value:
                return value

    return None


# ============================================================
# API KEY
# ============================================================

def get_api_key():
    """
    Get Gemini API key from .env.
    """

    api_key = get_env_value("GEMINI_API_KEY")

    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing in .env.\n\n"
            f"Expected file:\n{ENV_FILE}\n\n"
            "Expected format:\n"
            "GEMINI_API_KEY=YOUR_API_KEY"
        )

    return api_key


# ============================================================
# MODEL NAME
# ============================================================

def get_model_name():

    model_name = get_env_value("GEMINI_MODEL")

    if not model_name:
        model_name = DEFAULT_MODEL

    return model_name


# ============================================================
# PYDANTIC RESPONSE MODELS
# ============================================================

class Difference(BaseModel):
    topic: str = Field(default="")
    document_a: str = Field(default="")
    document_b: str = Field(default="")


class KeyDetail(BaseModel):
    category: str = Field(default="")
    document_a: str = Field(default="")
    document_b: str = Field(default="")


class ComparisonResult(BaseModel):

    summary_a: str = Field(default="")

    summary_b: str = Field(default="")

    similarities: List[str] = Field(
        default_factory=list
    )

    differences: List[Difference] = Field(
        default_factory=list
    )

    key_details: List[KeyDetail] = Field(
        default_factory=list
    )

    conclusion: str = Field(default="")

    limitations: List[str] = Field(
        default_factory=list
    )


# ============================================================
# CLEAN MODEL JSON RESPONSE
# ============================================================

def clean_json_response(response_text: str):

    if not response_text:
        raise RuntimeError(
            "Gemini returned an empty response."
        )

    text = response_text.strip()

    # Remove markdown JSON code fences
    text = re.sub(
        r"^```json\s*",
        "",
        text,
        flags=re.IGNORECASE
    )

    text = re.sub(
        r"^```\s*",
        "",
        text
    )

    text = re.sub(
        r"\s*```$",
        "",
        text
    )

    text = text.strip()

    return text


# ============================================================
# VALIDATE DOCUMENT LENGTH
# ============================================================

def validate_documents(text_a: str, text_b: str):

    if not text_a or not text_a.strip():
        raise RuntimeError(
            "Document A contains no extractable text."
        )

    if not text_b or not text_b.strip():
        raise RuntimeError(
            "Document B contains no extractable text."
        )

    total_length = len(text_a) + len(text_b)

    if total_length > MAX_TOTAL_CHARS:

        raise RuntimeError(
            "The combined document text is too long.\n\n"
            f"Maximum allowed characters: {MAX_TOTAL_CHARS:,}\n"
            f"Received: {total_length:,}\n\n"
            "Please use shorter documents."
        )


# ============================================================
# PROMPT
# ============================================================

def build_prompt(
    document_a: str,
    document_b: str
):

    prompt = f"""
You are an AI Document Comparison Assistant.

Your task is to compare TWO documents.

IMPORTANT RULES:

1. Use ONLY the text provided below.
2. Do NOT use outside knowledge.
3. Do NOT invent facts.
4. Do NOT assume missing information.
5. Keep Document A and Document B facts separate.
6. If a detail is not available, write exactly:
   "Not found in the provided text."
7. Compare important details such as:
   - dates
   - names
   - amounts
   - prices
   - requirements
   - deadlines
   - eligibility
   - responsibilities
   - quantities
   - terms
8. Identify both similarities and differences.
9. Give a neutral conclusion.
10. Do not provide legal advice.
11. Do not say that documents are legally equivalent, compliant,
    legally safe, or legally valid.
12. Return ONLY valid JSON.
13. Do not use Markdown.
14. Do not put JSON inside ``` blocks.

DOCUMENT A
--------------------
{document_a}

DOCUMENT B
--------------------
{document_b}

Return JSON using EXACTLY this structure:

{{
  "summary_a": "Short factual summary of Document A",

  "summary_b": "Short factual summary of Document B",

  "similarities": [
    "Similarity 1",
    "Similarity 2"
  ],

  "differences": [
    {{
      "topic": "Topic",
      "document_a": "Fact from Document A",
      "document_b": "Fact from Document B"
    }}
  ],

  "key_details": [
    {{
      "category": "Dates",
      "document_a": "Document A date information",
      "document_b": "Document B date information"
    }},
    {{
      "category": "Names",
      "document_a": "Document A name information",
      "document_b": "Document B name information"
    }},
    {{
      "category": "Amounts",
      "document_a": "Document A amount information",
      "document_b": "Document B amount information"
    }},
    {{
      "category": "Requirements",
      "document_a": "Document A requirement information",
      "document_b": "Document B requirement information"
    }},
    {{
      "category": "Deadlines",
      "document_a": "Document A deadline information",
      "document_b": "Document B deadline information"
    }},
    {{
      "category": "Eligibility",
      "document_a": "Document A eligibility information",
      "document_b": "Document B eligibility information"
    }}
  ],

  "conclusion": "Neutral comparison conclusion",

  "limitations": [
    "Limitation 1",
    "Limitation 2"
  ]
}}
"""

    return prompt


# ============================================================
# COMPARE DOCUMENTS
# ============================================================

def compare_documents(
    document_a: str,
    document_b: str,
    *args,
    **kwargs
):

    # --------------------------------------------------------
    # Validate input documents
    # --------------------------------------------------------

    validate_documents(
        document_a,
        document_b
    )

    # --------------------------------------------------------
    # Get API key
    # --------------------------------------------------------

    api_key = get_api_key()

    # --------------------------------------------------------
    # Get model
    # --------------------------------------------------------

    model_name = get_model_name()

    # --------------------------------------------------------
    # Create Gemini client
    # --------------------------------------------------------

    try:

        client = genai.Client(
            api_key=api_key
        )

    except Exception as e:

        raise RuntimeError(
            f"Could not initialize Gemini client:\n{e}"
        )

    # --------------------------------------------------------
    # Create prompt
    # --------------------------------------------------------

    prompt = build_prompt(
        document_a,
        document_b
    )

    # --------------------------------------------------------
    # Call Gemini
    # --------------------------------------------------------

    try:

        response = client.models.generate_content(

            model=model_name,

            contents=prompt,

            config={
                "response_mime_type": "application/json",
                "temperature": 0.1,
            }
        )

    except Exception as e:

        error_text = str(e)

        # Friendly error messages
        if "401" in error_text or "403" in error_text:

            raise RuntimeError(
                "Gemini API authentication/permission error.\n\n"
                "Please check your Gemini API key and API access."
            )

        if "429" in error_text:

            raise RuntimeError(
                "Gemini API rate limit reached.\n\n"
                "Please wait for a while and try again."
            )

        if "404" in error_text:

            raise RuntimeError(
                f"Gemini model was not found:\n{model_name}\n\n"
                "Check GEMINI_MODEL in your .env file."
            )

        if "500" in error_text or "503" in error_text:

            raise RuntimeError(
                "Gemini service is temporarily unavailable.\n\n"
                "Please try again."
            )

        raise RuntimeError(
            f"Gemini API error:\n{error_text}"
        )

    # --------------------------------------------------------
    # Get response text
    # --------------------------------------------------------

    try:

        response_text = response.text

    except Exception as e:

        raise RuntimeError(
            f"Could not read Gemini response:\n{e}"
        )

    # --------------------------------------------------------
    # Clean JSON
    # --------------------------------------------------------

    response_text = clean_json_response(
        response_text
    )

    # --------------------------------------------------------
    # Parse JSON
    # --------------------------------------------------------

    try:

        data = json.loads(
            response_text
        )

    except json.JSONDecodeError as e:

        raise RuntimeError(
            "Gemini returned invalid JSON.\n\n"
            f"JSON error: {e}\n\n"
            f"Response received:\n{response_text[:3000]}"
        )

    # --------------------------------------------------------
    # Validate response structure
    # --------------------------------------------------------

    try:

        result = ComparisonResult.model_validate(
            data
        )

    except Exception as e:

        raise RuntimeError(
            "Gemini response did not match the expected format.\n\n"
            f"Validation error:\n{e}"
        )

    # --------------------------------------------------------
    # Return result
    # --------------------------------------------------------

    return result